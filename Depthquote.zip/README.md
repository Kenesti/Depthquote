# Depthquote - Stock Analysis Platform

A comprehensive Node.js application for analyzing stocks using technical indicators, candlestick patterns, and various prediction methods. Depthquote is designed to power a professional graphical frontend GUI with candle charts, historical data, and user-friendly interpretations.

## Features

### Technical Indicators
- **Trend Indicators**: SMA, EMA, WMA, MACD, ADX, Bollinger Bands, Ichimoku Cloud, Parabolic SAR, Supertrend, ATR
- **Momentum Indicators**: RSI, Stochastic Oscillator, Williams %R, CCI, ROC, Momentum, Awesome Oscillator, MFI, Chaikin Money Flow, Ultimate Oscillator
- **Volume Indicators**: OBV, VWAP, Chaikin Oscillator, Klinger Oscillator, Volume Price Trend, NVI, PVI, Volume Ratio, Ease of Movement, Force Index, Money Stream
- **Volatility Indicators**: ATR, Bollinger Bands %B, BB Width, Donchian Channels, Keltner Channels, Historical Volatility, Standard Deviation, Variance, Beta, Alpha, Sharpe Ratio, Sortino Ratio

### Candlestick Pattern Recognition
- **Bullish Patterns**: Hammer, Inverted Hammer, Bullish Engulfing, Piercing Line, Morning Star, Three White Soldiers, Bullish Harami, Tweezer Bottom, Three Inside Up, Rising Three Methods
- **Bearish Patterns**: Shooting Star, Hanging Man, Bearish Engulfing, Dark Cloud Cover, Evening Star, Three Black Crows, Bearish Harami, Tweezer Top, Three Inside Down, Falling Three Methods
- **Neutral Patterns**: Doji, Spinning Top, Long-Legged Doji, Dragonfly Doji, Gravestone Doji, High Wave, Marubozu

### Chart Pattern Recognition
- **Reversal Patterns**: Head and Shoulders, Inverse Head and Shoulders, Double Top, Double Bottom, Triple Top, Triple Bottom, Rounding Top, Rounding Bottom, V Top, V Bottom
- **Continuation Patterns**: Ascending Triangle, Descending Triangle, Symmetrical Triangle, Flag, Pennant, Rectangle, Rising Wedge, Falling Wedge
- **Bilateral Patterns**: Cup and Handle
- **Gap Patterns**: Breakaway Gap, Exhaustion Gap, Island Reversal

### Prediction Methods
- **Statistical Models**: Linear Regression, Polynomial Regression, Exponential Regression, ARIMA, SARIMA, Holt-Winters, Prophet
- **Machine Learning Models**: LSTM, Random Forest, Gradient Boosting, SVM, Ensemble
- **Technical Models**: Moving Average Crossover, Bollinger Band Width, RSI Divergence, MACD Histogram, Support/Resistance, Volume-Based

### Analysis Engine
- Combines all technical indicators, patterns, and predictions
- Generates comprehensive buy/sell recommendations
- Provides price targets and risk metrics
- Calculates confidence scores for signals

## Installation

```bash
cd stock-analysis-engine
npm install
```

## Usage

### As a Library

```javascript
const engine = require('./stock-analysis-engine');

// Start the engine
engine.start();

// Analyze a stock
const result = await engine.analyze('AAPL');
console.log(result);

// Get summary
const summary = engine.getSummary(result);
console.log(summary);

// Get historical data
const historicalData = await engine.getHistoricalData('AAPL', { period: '3mo' });

// Calculate specific indicator
const dataWithRSI = engine.calculateIndicator(historicalData, 'rsi', { period: 14 });

// Identify patterns
const dataWithPatterns = await engine.identifyPatterns(historicalData);

// Generate predictions
const predictions = await engine.predict(historicalData, { forecastHorizon: 5 });
```

### As an API Server

```bash
# Start the API server
node index.js

# Or with custom port
PORT=3001 node index.js
```

The API server will start on the specified port (default: 3000).

## API Endpoints

### GET /api/health
Health check endpoint

```bash
curl http://localhost:3000/api/health
```

### POST /api/analyze
Analyze one or more stocks

```bash
curl -X POST http://localhost:3000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"symbols": ["AAPL", "GOOGL"], "options": { "period": "3mo" }}'
```

### GET /api/analyze?symbols=AAPL,GOOGL&period=3mo
Analyze stocks via GET request

### GET /api/historical?symbol=AAPL&period=1y&interval=1d
Get historical data for a stock

### GET /api/indicators?symbol=AAPL&indicators=rsi,macd
Get specific indicators for a stock

### GET /api/patterns?symbol=AAPL&patternType=bullish
Get patterns for a stock (filter by type)

### GET /api/predictions?symbol=AAPL&models=linear_regression,arima
Get predictions using specific models

## Project Structure

```
stock-analysis-engine/
├── config/
│   └── constants.js          # Configuration constants
├── lib/
│   ├── data/
│   │   ├── dataScraper.js     # Data scraping from Yahoo Finance
│   │   └── dataProcessor.js   # Data processing utilities
│   ├── indicators/
│   │   ├── index.js           # Technical indicators master module
│   │   ├── trendIndicators.js # Trend-based indicators
│   │   ├── momentumIndicators.js # Momentum-based indicators
│   │   ├── volumeIndicators.js # Volume-based indicators
│   │   └── volatilityIndicators.js # Volatility-based indicators
│   ├── patterns/
│   │   ├── index.js           # Pattern recognition master module
│   │   ├── candlePatterns.js   # Candlestick pattern recognition
│   │   └── chartPatterns.js   # Chart pattern recognition
│   └── prediction/
│       ├── index.js           # Prediction engine master module
│       ├── statisticalModels.js # Statistical prediction models
│       ├── machineLearningModels.js # Machine learning models
│       └── technicalModels.js  # Technical analysis-based models
├── services/
│   └── apiService.js          # RESTful API service
├── utils/
│   ├── index.js               # Utilities exports
│   ├── validation.js          # Validation utilities
│   └── errorHandler.js        # Error handling utilities
├── package.json
└── index.js                  # Main entry point
```

## Configuration

The engine uses configuration constants defined in `config/constants.js`. You can modify these to adjust:
- Data sources (Yahoo Finance, Alpha Vantage)
- Analysis periods
- Indicator thresholds
- Pattern definitions
- Prediction methods
- API endpoints
- Rate limits
- Cache settings

## Error Handling

The engine provides comprehensive error handling with custom error classes:
- `StockAnalysisError` - Base error class
- `ValidationError` - Input validation errors
- `DataError` - Data-related errors
- `SymbolError` - Invalid stock symbol errors
- `RateLimitError` - Rate limiting errors

## Rate Limiting

The API includes built-in rate limiting (60 requests per minute by default). You can adjust this in the constants file.

## Caching

The engine caches analysis results to improve performance. Cache settings can be adjusted in the constants file.

## Dependencies

- `express` - Web framework
- `cors` - CORS middleware
- `axios` - HTTP client
- `yfinance` - Yahoo Finance API client
- `moment` - Date manipulation
- `@tensorflow/tfjs-node` - TensorFlow for JavaScript (for ML models)
- And others...

## Frontend Integration

The backend is designed to support a graphical frontend GUI. It provides:

1. **Historical Data**: OHLCV data for candle charts
2. **Technical Indicators**: Values for plotting indicators on charts
3. **Pattern Recognition**: Identified patterns for display
4. **Predictions**: Forecasted prices and signals
5. **Recommendations**: Buy/sell signals with confidence scores

Example frontend integration:

```javascript
// Fetch analysis for a stock
const response = await fetch('/api/analyze', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ symbols: ['AAPL'] })
});

const result = await response.json();

// Use the data to render candle charts
const historicalData = result.results[0].historicalData;

// Display technical indicators
const indicators = result.results[0].technicalAnalysis;

// Show patterns
const patterns = result.results[0].patternAnalysis;

// Display recommendations
const recommendations = result.results[0].recommendations;
```

## Future Enhancements

The engine is designed to be modular and extensible. Future enhancements can include:

1. Additional data sources (Alpha Vantage, IEX Cloud, etc.)
2. More technical indicators
3. Additional candlestick and chart patterns
4. More sophisticated machine learning models
5. Real-time data streaming
6. Backtesting framework
7. Portfolio analysis
8. Risk management tools

## License

MIT
