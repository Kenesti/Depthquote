/**
 * Error Handler Module
 * Centralized error handling for the stock analysis engine
 */

const { ERROR_CODES } = require('../config/constants');

class ErrorHandler {
  constructor() {
    // Custom error classes
    this.StockAnalysisError = class StockAnalysisError extends Error {
      constructor(message, code = ERROR_CODES.INTERNAL_ERROR, details = null) {
        super(message);
        this.name = 'StockAnalysisError';
        this.code = code;
        this.details = details;
        this.timestamp = new Date().toISOString();
        this.isStockAnalysisError = true;
      }
    };

    this.ValidationError = class ValidationError extends this.StockAnalysisError {
      constructor(message, details = null) {
        super(message, ERROR_CODES.INVALID_PARAMETERS, details);
        this.name = 'ValidationError';
      }
    };

    this.DataError = class DataError extends this.StockAnalysisError {
      constructor(message, details = null) {
        super(message, ERROR_CODES.DATA_NOT_AVAILABLE, details);
        this.name = 'DataError';
      }
    };

    this.SymbolError = class SymbolError extends this.StockAnalysisError {
      constructor(message, details = null) {
        super(message, ERROR_CODES.INVALID_SYMBOL, details);
        this.name = 'SymbolError';
      }
    };

    this.RateLimitError = class RateLimitError extends this.StockAnalysisError {
      constructor(message, details = null) {
        super(message, ERROR_CODES.RATE_LIMITED, details);
        this.name = 'RateLimitError';
      }
    };
  }

  /**
   * Create a stock analysis error
   * @param {string} message - Error message
   * @param {string} code - Error code
   * @param {object} details - Additional error details
   * @returns {Error} Stock analysis error
   */
  createError(message, code = ERROR_CODES.INTERNAL_ERROR, details = null) {
    return new this.StockAnalysisError(message, code, details);
  }

  /**
   * Create a validation error
   * @param {string} message - Error message
   * @param {object} details - Validation details
   * @returns {Error} Validation error
   */
  createValidationError(message, details = null) {
    return new this.ValidationError(message, details);
  }

  /**
   * Create a data error
   * @param {string} message - Error message
   * @param {object} details - Data details
   * @returns {Error} Data error
   */
  createDataError(message, details = null) {
    return new this.DataError(message, details);
  }

  /**
   * Create a symbol error
   * @param {string} message - Error message
   * @param {object} details - Symbol details
   * @returns {Error} Symbol error
   */
  createSymbolError(message, details = null) {
    return new this.SymbolError(message, details);
  }

  /**
   * Create a rate limit error
   * @param {string} message - Error message
   * @param {object} details - Rate limit details
   * @returns {Error} Rate limit error
   */
  createRateLimitError(message, details = null) {
    return new this.RateLimitError(message, details);
  }

  /**
   * Handle errors and convert to appropriate format
   * @param {Error} error - The error to handle
   * @returns {object} Formatted error
   */
  handleError(error) {
    if (error.isStockAnalysisError) {
      return {
        error: {
          code: error.code,
          message: error.message,
          details: error.details,
          timestamp: error.timestamp
        }
      };
    }

    // Check for common error types
    if (error.name === 'ValidationError') {
      return this.handleError(this.createValidationError(error.message));
    }

    if (error.message.includes('No data available')) {
      return this.handleError(this.createDataError(error.message));
    }

    if (error.message.includes('Invalid symbol')) {
      return this.handleError(this.createSymbolError(error.message));
    }

    if (error.message.includes('Rate limit')) {
      return this.handleError(this.createRateLimitError(error.message));
    }

    // Generic error
    return this.handleError(this.createError(error.message));
  }

  /**
   * Handle API errors
   * @param {Error} error - The error to handle
   * @param {object} req - Express request object
   * @param {object} res - Express response object
   */
  handleApiError(error, req, res) {
    const formattedError = this.handleError(error);

    // Determine HTTP status code
    let statusCode = 500;
    switch (formattedError.error.code) {
      case ERROR_CODES.INVALID_PARAMETERS:
        statusCode = 400;
        break;
      case ERROR_CODES.INVALID_SYMBOL:
      case ERROR_CODES.DATA_NOT_AVAILABLE:
        statusCode = 404;
        break;
      case ERROR_CODES.RATE_LIMITED:
        statusCode = 429;
        break;
      default:
        statusCode = 500;
    }

    // Send error response
    res.status(statusCode).json(formattedError);
  }

  /**
   * Log error
   * @param {Error} error - The error to log
   * @param {string} context - Context for the error
   */
  logError(error, context = '') {
    const timestamp = new Date().toISOString();
    const errorInfo = {
      timestamp,
      context,
      name: error.name,
      message: error.message,
      code: error.code,
      stack: error.stack
    };

    console.error('[ERROR]', errorInfo);
  }

  /**
   * Wrap async function with error handling
   * @param {Function} fn - Async function to wrap
   * @returns {Function} Wrapped function
   */
  asyncWrapper(fn) {
    return async (req, res, next) => {
      try {
        await fn(req, res, next);
      } catch (error) {
        this.handleApiError(error, req, res);
      }
    };
  }

  /**
   * Create error middleware for Express
   * @returns {Function} Express error middleware
   */
  createErrorMiddleware() {
    return (error, req, res, next) => {
      this.handleApiError(error, req, res);
    };
  }

  /**
   * Check if error is a stock analysis error
   * @param {Error} error - Error to check
   * @returns {boolean} True if stock analysis error
   */
  isStockAnalysisError(error) {
    return error && error.isStockAnalysisError === true;
  }

  /**
   * Get error details as string
   * @param {Error} error - Error to format
   * @returns {string} Formatted error details
   */
  getErrorDetails(error) {
    if (!error) {
      return 'No error provided';
    }

    const details = [];
    details.push(`Error: ${error.name || 'Error'}`);
    details.push(`Message: ${error.message || 'No message'}`);

    if (error.code) {
      details.push(`Code: ${error.code}`);
    }

    if (error.details) {
      details.push(`Details: ${JSON.stringify(error.details)}`);
    }

    if (error.timestamp) {
      details.push(`Timestamp: ${error.timestamp}`);
    }

    return details.join('\n');
  }
}

module.exports = new ErrorHandler();
