/**
 * Utilities Module Index
 * Exports all utility functions
 */

const validation = require('./validation');
const errorHandler = require('./errorHandler');

module.exports = {
  // Validation utilities
  validation: validation,

  // Error handling
  errorHandler: errorHandler,
  
  // Custom error classes
  StockAnalysisError: errorHandler.StockAnalysisError,
  ValidationError: errorHandler.ValidationError,
  DataError: errorHandler.DataError,
  SymbolError: errorHandler.SymbolError,
  RateLimitError: errorHandler.RateLimitError
};
